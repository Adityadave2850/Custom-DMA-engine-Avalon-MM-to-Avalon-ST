# Streaming DMA IP — portable Avalon-MM/Avalon-ST core

This is your original bring-up project turned into a self-contained, standard,
reusable IP block: **no Quartus Platform Designer / Qsys dependency**, a
**fixed, protocol-correct DMA engine**, a **memory model and sink that were
missing**, and a **self-checking testbench** with GTKWave visibility into
every handshake signal.

## What was wrong with the original files

| File | Problem |
|---|---|
| `dma_engine.v` | The FSM had `// BYPASS` comments and never actually checked `amm_waitrequest` or `amm_readdatavalid`. It also asserted/deasserted `amm_read` in the same clock edge, so a real memory would never even see the request. It streamed the *address*, not real memory data. |
| `avalon_test.v` | Instantiated `mem_system`, a Quartus Platform-Designer/Qsys-generated component that isn't portable RTL — it doesn't exist outside that one Quartus project and can't be simulated standalone. It also instantiated `avalon_consumer`, which **did not exist anywhere in the project** — the design could never elaborate. |
| `avalon_producer.v` | Worked fine on its own; kept with just comment cleanup. |

## New / fixed architecture

```
                    ┌────────────────────── streaming_dma_ip.v ───────────────────────┐
                    │                                                                  │
                    │   avalon_onchip_mem.v  --Avalon-MM-->   dma_engine.v            │
                    │   (memory slave,          (read master +                        │
                    │    replaces Qsys           Avalon-ST source)                    │
                    │    mem_system)                    │                             │
                    │                                    │ Avalon-ST                  │
                    │                                    v                            │
                    │                            avalon_consumer.v                    │
                    │                            (sink, NEW — was                      │
                    │                             missing entirely)                    │
                    │                                    │                            │
                    └────────────────────────────────────┼────────────────────────────┘
                                                     led_output[7:0]
```

* **`dma_engine.v`** — corrected. Real Avalon-MM read master (properly holds
  `amm_read` until `amm_waitrequest` deasserts, waits for `amm_readdatavalid`
  before using data) driving a real Avalon-ST source. Streams the actual
  low byte of memory data, not the address. Same state names/interface as
  your original, just fixed.
* **`avalon_onchip_mem.v`** — **new**. A plain-Verilog Avalon-MM slave RAM
  (parameterizable depth/latency) that replaces the Qsys `mem_system`. This
  is the key step that makes the whole thing portable: it's synthesizable on
  any FPGA toolchain, not just Quartus with a specific Platform Designer
  system file. It also has a configurable stall generator so the master's
  `waitrequest` handling is actually exercised.
* **`avalon_consumer.v`** — **new**. The Avalon-ST sink your top level
  referenced but never had. Latches accepted bytes onto `led_output`, with
  an optional backpressure generator to exercise `ready`/`valid` on the
  source side too.
* **`avalon_producer.v`** — kept as-is (cleaned comments only) as a small,
  independently reusable free-running source IP for simple bring-up tests
  that don't need the full DMA path.
* **`streaming_dma_ip.v`** — **new top-level IP**. Wires the above together
  behind a clean, board-agnostic port list (`clk`, `reset_n`, `led_output`,
  plus debug taps). This is the file you drop into any project/any board.
* **`avalon_test.v`** — reduced to what it should be: a thin, board-specific
  **pin wrapper** (`CLOCK_50` / `KEY` / `LEDG`) around `streaming_dma_ip`.
  Porting to a different board means editing only this file.

## Verification

Two self-checking testbenches, both with `$dumpvars` VCD output:

* **`tb/tb_streaming_dma_ip.v`** — the main test. Runs the full
  mem → DMA → stream → sink pipeline with a small (16-word) memory so the
  address counter wraps multiple times, *and* with both memory-side and
  sink-side stall generators enabled, so real backpressure on both the
  Avalon-MM and Avalon-ST interfaces is exercised, not just the ideal case.
  A scoreboard independently predicts each expected byte from the memory's
  known init pattern and flags any mismatch immediately. Last run:
  **357 transfers checked, 0 mismatches, PASS.**
* **`tb/tb_producer_consumer.v`** — a secondary test proving the standalone
  `avalon_producer` + `avalon_consumer` chain works on its own (counter
  sequence 0..255 wraps, no skips/repeats even with sink backpressure).
  Last run: **500 transfers checked, 0 mismatches, PASS.**

### Build & run

```bash
cd sim
./run_sims.sh
```

(Needs `iverilog`/`vvp` — Icarus Verilog — installed: `sudo apt-get install
iverilog gtkwave`.)

### View in GTKWave

```bash
cd sim
gtkwave streaming_dma_ip.vcd streaming_dma_ip.gtkw   # main test, pre-arranged signals
gtkwave producer_consumer.vcd                         # secondary test
```

`streaming_dma_ip.gtkw` is a saved GTKWave layout that groups the signals
into the three things worth watching:

1. **Avalon-MM master↔slave**: `dbg_amm_address`, `dbg_amm_read`,
   `dbg_amm_waitrequest`, `dbg_amm_readdata`, `dbg_amm_readdatavalid` — watch
   `amm_read` stay high across stall cycles until `waitrequest` drops, then
   `readdatavalid` pulse `LATENCY` cycles later.
2. **Avalon-ST source↔sink**: `dbg_stream_data`, `dbg_stream_valid`,
   `dbg_stream_ready` — watch `valid` held until `ready`, and `ready` drop
   periodically (sink backpressure) with `valid` correctly stalling too.
3. **Result**: `led_output` (the byte that actually reached the "board"),
   `dbg_xfer_count` (running transfer count) — climbs steadily, dips to 0
   at each address wrap.

## File map

```
rtl/
  dma_engine.v          - Avalon-MM read master + Avalon-ST source (fixed)
  avalon_onchip_mem.v   - Avalon-MM slave memory model (new, replaces Qsys mem_system)
  avalon_consumer.v     - Avalon-ST sink (new, was missing)
  avalon_producer.v     - standalone free-running Avalon-ST source (kept)
  streaming_dma_ip.v    - portable top-level IP core (new)
  avalon_test.v         - board-level pin wrapper (rewritten, no Qsys dependency)
tb/
  tb_streaming_dma_ip.v     - main self-checking testbench
  tb_producer_consumer.v    - secondary self-checking testbench
sim/
  run_sims.sh               - build+run both testbenches
  streaming_dma_ip.vcd      - waveform from main testbench (generated)
  producer_consumer.vcd     - waveform from secondary testbench (generated)
  streaming_dma_ip.gtkw     - saved GTKWave signal layout for the main waveform
```

## Porting to a new board

Only `rtl/avalon_test.v` is board-specific. To move to another board:
1. Copy `avalon_test.v`, rename its ports to your board's actual pin names
   (clock, reset button/switch, LEDs).
2. Keep the `streaming_dma_ip` instantiation and its parameters unchanged.
3. Add all files under `rtl/` to your project and set `avalon_test.v` (or
   your renamed copy) as top level.

No Qsys/Platform Designer system file is required anywhere in this flow.
